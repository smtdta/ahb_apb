// ============================================================
// APB AGENT
// ============================================================

class apb_agent extends uvm_agent;

  // ----------------------------------------------------------
  // Factory Registration
  // ----------------------------------------------------------
  `uvm_component_utils(apb_agent)


  // ----------------------------------------------------------
  // Component Handles
  // ----------------------------------------------------------
  apb_sequencer apb_sqr_o;
  apb_driver    apb_drv_o;


  // ----------------------------------------------------------
  // Constructor
  // ----------------------------------------------------------
  function new(string name = "apb_agent",
               uvm_component parent = null);

    super.new(name, parent);

  endfunction


  // ----------------------------------------------------------
  // Build Phase
  // ----------------------------------------------------------
  function void build_phase(uvm_phase phase);

    super.build_phase(phase);

    // Create sequencer
    apb_sqr_o = apb_sequencer::type_id::create(
      "apb_sqr_o",
      this
    );

    // Create driver
    apb_drv_o = apb_driver::type_id::create(
      "apb_drv_o",
      this
    );

  endfunction


  // ----------------------------------------------------------
  // Connect Phase
  // ----------------------------------------------------------
  function void connect_phase(uvm_phase phase);

    super.connect_phase(phase);

    // Connect driver to sequencer
    apb_drv_o.seq_item_port.connect(
      apb_sqr_o.seq_item_export
    );

  endfunction

endclass