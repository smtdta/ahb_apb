// ============================================================
// BRIDGE TEST
// ============================================================

class bridge_test extends uvm_test;

  // ----------------------------------------------------------
  // Factory Registration
  // ----------------------------------------------------------
  `uvm_component_utils(bridge_test)


  // ----------------------------------------------------------
  // Handles
  // ----------------------------------------------------------
  bridge_env env_o;

  bridge_virtual_sequence vseq;
  

  // ----------------------------------------------------------
  // Constructor
  // ----------------------------------------------------------
  function new(string name = "bridge_test",
               uvm_component parent = null);

    super.new(name, parent);

  endfunction


  // ----------------------------------------------------------
  // Build Phase
  // ----------------------------------------------------------
  function void build_phase(uvm_phase phase);

    super.build_phase(phase);

    // Create environment
    env_o = bridge_env::type_id::create(
      "env_o",
      this
    );

  endfunction


  // ----------------------------------------------------------
  // Run Phase
  // ----------------------------------------------------------
  task run_phase(uvm_phase phase);

    phase.raise_objection(this);

    // --------------------------------------------------------
    // Reset DUT
    // --------------------------------------------------------
    tb_top.reset_dut();
  
    vseq = bridge_virtual_sequence::type_id::create("vseq");
    
    // Start the virtual sequence on the virtual sequencer
    vseq.start(env_o.vsqr_o);

    phase.drop_objection(this);

  endtask

endclass