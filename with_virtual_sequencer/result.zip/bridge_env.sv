// ============================================================
// BRIDGE ENVIRONMENT
// ============================================================

class bridge_env extends uvm_env;

  // ----------------------------------------------------------
  // Factory Registration
  // ----------------------------------------------------------
  `uvm_component_utils(bridge_env)


  // ----------------------------------------------------------
  // Handles
  // ----------------------------------------------------------
  ahb_agent ahb_agent_o;
  apb_agent apb_agent_o;

  bridge_virtual_sequencer vsqr_o;


  // ----------------------------------------------------------
  // Constructor
  // ----------------------------------------------------------
  function new(string name = "bridge_env",
               uvm_component parent = null);

    super.new(name, parent);

  endfunction


  // ----------------------------------------------------------
  // Build Phase
  // ----------------------------------------------------------
  function void build_phase(uvm_phase phase);

    super.build_phase(phase);

    // Create AHB agent
    ahb_agent_o = ahb_agent::type_id::create(
      "ahb_agent_o",
      this
    );

    // Create APB agent
    apb_agent_o = apb_agent::type_id::create(
      "apb_agent_o",
      this
    );

    // Create virtual sequencer
    vsqr_o = bridge_virtual_sequencer::type_id::create(
      "vsqr_o",
      this
    );

  endfunction


  // ----------------------------------------------------------
  // Connect Phase
  // ----------------------------------------------------------
  function void connect_phase(uvm_phase phase);

    super.connect_phase(phase);

    // Assign handles to the existing agent sequencers
    vsqr_o.ahb_sqr = ahb_agent_o.ahb_sqr_o;
    vsqr_o.apb_sqr = apb_agent_o.apb_sqr_o;

  endfunction

endclass