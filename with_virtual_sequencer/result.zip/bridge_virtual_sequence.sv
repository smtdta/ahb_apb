// ============================================================
// BRIDGE VIRTUAL SEQUENCE
// ============================================================

class bridge_virtual_sequence extends uvm_sequence;

  `uvm_object_utils(bridge_virtual_sequence)
  `uvm_declare_p_sequencer(bridge_virtual_sequencer)

  // Child sequence handles
  apb_write_seq apb_wr_seq;
  apb_read_seq  apb_rd_seq;

  ahb_write_seq ahb_wr_seq;
  ahb_read_seq  ahb_rd_seq;


  function new(string name = "bridge_virtual_sequence");
    super.new(name);
  endfunction


  task body();

    // Create child sequences
    apb_wr_seq = apb_write_seq::type_id::create("apb_wr_seq");
    apb_rd_seq = apb_read_seq::type_id::create("apb_rd_seq");

    ahb_wr_seq = ahb_write_seq::type_id::create("ahb_wr_seq");
    ahb_rd_seq = ahb_read_seq::type_id::create("ahb_rd_seq");

    // 1. APB write
    apb_wr_seq.start(p_sequencer.apb_sqr);

    // 2. AHB read
    ahb_rd_seq.start(p_sequencer.ahb_sqr);

    // 3. AHB write
    ahb_wr_seq.start(p_sequencer.ahb_sqr);

    // 4. APB read
    apb_rd_seq.start(p_sequencer.apb_sqr);

  endtask

endclass