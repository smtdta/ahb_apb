class bridge_virtual_sequencer extends uvm_sequencer;

  `uvm_component_utils(bridge_virtual_sequencer)

  ahb_sequencer ahb_sqr;
  apb_sequencer apb_sqr;
  
 /* this is in agent ahb & apb 
  apb_sequencer apb_sqr_o;
  apb_driver    apb_drv_o; 
  
  ahb_sequencer ahb_sqr_o;
  ahb_driver    ahb_drv_o; */

  function new(string name = "bridge_virtual_sequencer",
               uvm_component parent = null);
    super.new(name, parent);
  endfunction

endclass