// ============================================================
// AHB AGENT
// ============================================================

class ahb_agent extends uvm_agent;

  // ----------------------------------------------------------
  // Factory Registration
  // ----------------------------------------------------------
  `uvm_component_utils(ahb_agent)


  // ----------------------------------------------------------
  // Component Handles
  // ----------------------------------------------------------
  ahb_sequencer ahb_sqr_o;
  ahb_driver    ahb_drv_o;


  // ----------------------------------------------------------
  // Constructor
  // ----------------------------------------------------------
  function new(string name = "ahb_agent",
               uvm_component parent = null);

    super.new(name, parent);

  endfunction


  // ----------------------------------------------------------
  // Build Phase
  // ----------------------------------------------------------
  function void build_phase(uvm_phase phase);

    super.build_phase(phase);

    // Create sequencer
    ahb_sqr_o = ahb_sequencer::type_id::create(
      "ahb_sqr_o",
      this
    );

    // Create driver
    ahb_drv_o = ahb_driver::type_id::create(
      "ahb_drv_o",
      this
    );

  endfunction


  // ----------------------------------------------------------
  // Connect Phase
  // ----------------------------------------------------------
  function void connect_phase(uvm_phase phase);

    super.connect_phase(phase);

    // Connect driver to sequencer
    ahb_drv_o.seq_item_port.connect(
      ahb_sqr_o.seq_item_export
    );

  endfunction

endclass